//
//  ShuftiPro.h
//  ShuftiPro
//
//  Created by Swift Developer on 10/3/18.
//  Copyright © 2018 Programmers Force. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ShuftiPro.
FOUNDATION_EXPORT double ShuftiProVersionNumber;

//! Project version string for ShuftiPro.
FOUNDATION_EXPORT const unsigned char ShuftiProVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ShuftiPro/PublicHeader.h>


